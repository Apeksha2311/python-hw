import requests
import json
URL='http://127.0.0.1:8000/create_data/'
data ={
    "name":'rohit',
    "roll":6,
    "course":'HTML'
}
json_data=json.dumps(data)

r= requests.post(url = URL ,data = json_data)

response = r.json()

print(response)
