from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import io
from rest_framework.parsers import JSONParser
from . serializers import StudentSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse

# Create your views here.

@csrf_exempt
def create_data_view(request):
    if request.method == 'POST':
        json_data = request.body
        #print(json_data)
        stream = io.BytesIO(json_data)

        #converting json to python native data
        pythondata = JSONParser().parse(stream)

        serialize =StudentSerializer(data=pythondata)

        if serialize.is_valid():
            serialize.save()

            response = {'msg':'Data created'}
            json_data=JSONRenderer().render(response)

            return HttpResponse(json_data , content_type = 'application/json')

