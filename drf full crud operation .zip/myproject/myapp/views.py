from django.shortcuts import render
from rest_framework.parsers import JSONParser
import io
from . models import StudentModel
from . serializers import StudentSerializer

from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse

from django.views.decorators.csrf import csrf_exempt

# Create your views here.  
@csrf_exempt
def studentapi_view(request):
    if request.method == 'GET':
        data = request.body
        stream = io.BytesIO(data)

        pythondata =JSONParser().parse(stream)
        #print('python Data :',pythondata)


        id = pythondata.get('id',None)
        #print("id is",id)


        if id is not None:
            modeldata = StudentModel.objects.get(id=id)
            serialize = StudentSerializer(modeldata)

            json_data = JSONRenderer().render(serialize.data)

            return HttpResponse(json_data , content_type='application/json')

        modeldata = StudentModel.objects.all()
        serialize = StudentSerializer(modeldata , many = True)
        
        json_data = JSONRenderer().render(serialize.data)
        
        return HttpResponse(json_data , content_type='application/json')
    
    #post request
    if request.method == 'POST':
        data = request.body

        stream = io.BytesIO(data)

        python_data= JSONParser().parse(stream)

        serialize = StudentSerializer(data = python_data)

        if serialize.is_valid():
            serialize.save()

            response ={'msg':'successfully Data Post.'}
            json_data = JSONRenderer().render(response)

            return HttpResponse(json_data , content_type='application/json')

        json_data =JSONRenderer().render(serialize.errors)

        return HttpResponse(json_data , content_type='application/json')


    #put request
    if request.method == 'PUT':
        data = request.body

        stream = io.BytesIO(data)

        python_data = JSONParser().parse(stream)

        id=python_data.get('id')

        sid =StudentModel.objects.get(id=id)

        serialize =StudentSerializer(sid ,data=python_data,partial=True)
        if serialize.is_valid():
            serialize.save()
            response={'msg':'Data Updated..'}
            json_data=JSONRenderer().render(response)

            return HttpResponse(json_data , content_type ='application/json')

    #delete request
    if request.method == "DELETE":
        data = request.body

        stream = io.BytesIO(data)
        python_data = JSONParser().parse(stream)


        id=python_data.get('id')
        modeldata=StudentModel.objects.get(id=id)

        modeldata.delete()

        response={'msg':'data deleted successfully..'}
        json_data=JSONRenderer().render(response)

        return HttpResponse(json_data , content_type='application/json')

