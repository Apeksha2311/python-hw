

// var a=confirm('Please check your Email Id..');
// document.write(a);


// var b=alert('warning Message....');
// document.write(b);

// var r=prompt('enter your Surname:');
// document.write(r);


// #java script datatypes

// primitive data types

var a=10.5;
document.write(a+"<br>");
document.write(typeof(a)+"<br>");


var b='Apeksha Khot';
console.log(typeof(b));

var x=true;
var y=false;

console.log(typeof(x));
console.log(typeof(y));


var x1;
console.log(typeof(x1));

var a1 =null;
console.log(typeof(a1));