import requests
import json


URL = 'http://127.0.0.1:8000/studentapi/'

#get requests (read data)

def GetData(id=None):
    d={}
    if id is not None:
        d = {'id':id}

    json_data = json.dumps(d)
    r = requests.get(url =URL , data = json_data)
    return r.json()

get_data=GetData(1)
print(get_data)
