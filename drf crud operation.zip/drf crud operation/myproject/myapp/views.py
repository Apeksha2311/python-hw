from django.shortcuts import render
from rest_framework.parsers import JSONParser
import io
from . models import StudentModel
from . serializers import StudentSerializer

from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse

# Create your views here.  
def studentapi_view(request):
    if request.method == 'GET':
        data = request.body
        stream = io.BytesIO(data)

        pythondata =JSONParser().parse(stream)
        #print('python Data :',pythondata)


        id = pythondata.get('id',None)
        #print("id is",id)


        if id is not None:
            modeldata = StudentModel.objects.get(id=id)
            serialize = StudentSerializer(modeldata)

            json_data = JSONRenderer().render(serialize.data)

            return HttpResponse(json_data , content_type='application/json')

        modeldata = StudentModel.objects.all()
        serialize = StudentSerializer(modeldata , many = True)
        
        json_data = JSONRenderer().render(serialize.data)
        
        return HttpResponse(json_data , content_type='application/json')


