from django.shortcuts import render
from . models import StudentModel
from . serializers import StudentSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse

# Create your views here.
def get_data_view(request,id):
    data = StudentModel.objects.get(id=id)
    print(data)

    serialize =StudentSerializer(data)
    print(serialize)

    json_data = JSONRenderer().render(serialize.data)
    print(json_data)

    return HttpResponse(json_data,content_type='application/json')
