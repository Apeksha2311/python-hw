from django.urls import path
from . import views

urlpatterns = [
    path('get_data/<int:id>',views.get_data_view,name='get_data'),
]