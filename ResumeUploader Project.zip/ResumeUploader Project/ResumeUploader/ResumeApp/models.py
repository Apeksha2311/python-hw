from django.db import models

# Create your models here.






class ResumeModel(models.Model):
    fname=models.CharField(max_length=100)
    lname=models.CharField(max_length=100)
    email=models.EmailField()
    contact=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    dob=models.DateField(auto_now=False , auto_now_add=False)
    city=models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    pin=models.PositiveIntegerField()
    lang=models.CharField(max_length=100)
    lang_skills=models.CharField(max_length=100)
    prefered_loc=models.CharField(max_length=100)
    qual=models.CharField(max_length=100)
    profile_image =models.ImageField(upload_to="Profile_Images/" ,blank=True)
    projects =models.TextField()


