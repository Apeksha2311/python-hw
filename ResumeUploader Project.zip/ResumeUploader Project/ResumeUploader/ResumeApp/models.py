from django.db import models

# Create your models here.


city_choice=[('Mumbai','Mumbai'),('Thane','Thane'),('Nashik','Nashik'),('Pune','Pune'),('Raygad','Raygad'),('Nagpur','Nagpur'),('Kolphapur','Kolphapur')]

state_choice=[('Maharashtra','Maharashtra'),('UP','UP'),('Gujrat','Gujrat'),('Kerala','Kerala'),('Panji','Panji'),('MP','MP'),('Asam','Asam')]





class ResumeModel(models.Model):
    fname=models.CharField(max_length=100)
    lname=models.CharField(max_length=100)
    email=models.EmailField()
    contact=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    dob=models.DateField(auto_now=False , auto_now_add=False)
    city=models.CharField(choices=city_choice,max_length=100)
    state=models.CharField(choices=state_choice,max_length=100)
    pin=models.PositiveIntegerField()
    lang=models.CharField(max_length=100)
    lang_skills=models.CharField(max_length=100)
    prefered_loc=models.CharField(max_length=100)
    qual=models.CharField(max_length=100)
    profile_image =models.ImageField(upload_to="Profile_Images/" ,blank=True)
    projects =models.TextField()


