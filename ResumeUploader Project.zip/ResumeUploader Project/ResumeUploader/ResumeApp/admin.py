from django.contrib import admin
from . models import ResumeModel

# Register your models here.

@admin.register(ResumeModel)
class ResumeAdmin(admin.ModelAdmin):
    list_display=['id','fname','lname','email','contact',
    'gender','dob','city','state','pin','lang','lang_skills','prefered_loc',
    'qual','profile_image','projects']