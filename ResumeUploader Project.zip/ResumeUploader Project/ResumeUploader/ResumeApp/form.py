from django import forms
from . models import ResumeModel



gender_choice=[('male','male'),('female','female'),('Not to prefer','Not to prefer')]

lang_choice =[('Marathi','Marathi'),('Hindi','Hindi'),('English','English'),('Tamil','Tamil'),('Gujrati','Gujrati')]


city_choice=[('Mumbai','Mumbai'),('Thane','Thane'),('Nashik','Nashik'),('Pune','Pune'),('Raygad','Raygad'),('Nagpur','Nagpur'),('Kolphapur','Kolphapur')]

state_choice=[('Maharashtra','Maharashtra'),('UP','UP'),('Gujrat','Gujrat'),('Kerala','Kerala'),('Panji','Panji'),('MP','MP'),('Asam','Asam')]


lang_skills_choice=[('Python','Python'),('HTML','HTML'),('Java','Java'),('SQL','SQL'),('CSS','CSS'),('Node_js','Node_js')]

prefered_loc_choice=[('Mumbai','Mumbai'),('Pune','Pune'),('Nashil','Nashik'),('Banglore','Banglore')]

class ResumeForm(forms.ModelForm):
    gender = forms.ChoiceField(label="Select gender",choices=gender_choice,widget=forms.RadioSelect)

    lang = forms.MultipleChoiceField(choices=lang_choice , widget=forms.CheckboxSelectMultiple())

   
   
    lang_skills=forms.MultipleChoiceField(choices=lang_skills_choice , widget=forms.CheckboxSelectMultiple())
    
    prefered_loc=forms.ChoiceField(choices=prefered_loc_choice , widget=forms.RadioSelect)
    

    class Meta:
        model= ResumeModel

        fields = ['fname','lname','email','contact',
    'gender','dob','city','state','pin','lang','lang_skills','prefered_loc',
    'qual','profile_image','projects']

        labels={
            'fname':'Enter your First Name:',
            'lname':'Enter your last name:',
            'email':'Enter your email id:',
            'contact':'Enter Your contact No:',
            'gender':'Select gender',
            'dob':'Select Date of birth',
            'city':'Select city',
            'state':'Select State',
            'pin':'Enter pin code',
            'lang':'Select language',
            'lang_skills':'Select your Skills',
            'prefered_loc':'Select prefered location',
            'qual':'Enter your qualification',
            'profile_image':'Upload your profile img',
            'projects':'Enter Your Projects and details'
        }

        widgets = {
            'fname':forms.TextInput(attrs={'class':'form-control'}),
            'lname':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'contact':forms.TextInput(attrs={'class':'form-control'}),
            'city':forms.Select(attrs={'class':'form-control'}),
            'state':forms.Select(attrs={'class':'form-control'}),

            'pin':forms.NumberInput(attrs={'class':'form-control'}),
            'qual':forms.TextInput(attrs={'class':'form-control'}),
            

            'projects':forms.TextInput(attrs={'class':'form-control'}),

            

        }