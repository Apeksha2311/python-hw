from django.shortcuts import render
from django.views import View
from . form import ResumeForm

# Create your views here.

class home_view(View):
    def get(self ,request):
        forms = ResumeForm()
        context ={'forms':forms}
        return render(request,'ResumeApp/home.html',context)

    def post(self , request):
        pass


class all_candidates_view(View):
    def get(self ,request):
        pass

    def post(self , request):
        pass
    

class candidate_view(View):
    def get(self ,request):
        pass

    def post(self , request):
        pass
    

