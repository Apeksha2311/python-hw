from django.urls import path

from . import views

urlpatterns =[
    path('',views.home_view.as_view() , name='home'),
    path('all_candidates/' ,views.all_candidates_view.as_view(),name='all_candidates'),
    path('candidate/<int:id>' ,views.candidate_view.as_view(),name='candidate'),
]