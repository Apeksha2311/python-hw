
import pandas as pd
import numpy as np
df=pd.read_csv("info.csv")
print(df)
# print(type(df))

# fetch a single record
# a=df['name'].values
# print(a.ndim)


# #fetch a multiple record
# n=df[["name","age"]]
# print(n)
# r=df[["name","age"]].values
# print(r)
# print(type(r))
# print(r.ndim)

#fetch a maximum age from dataframe
# n=df["age"].max()
# print(n)

# # fetch a minimum age from a dataframe
# a=df["age"].min()
# print(a)

# #fetch a average age from a dataframe
# n1=df["age"].mean()
# print(n1)

# n2=df["age"].sum()
# print(n2)

# dataframe query
# n=df[df["loc"]=="thane"]
# print(n)

# n=df[df["age"]==df["age"].max()]
# print(n)

# a=df[df["age"]].max()
# print(a)

#rows and columns
#fetch first five rows
x=df.head()
print(x)

x1=df.head(2)
print(x1)

#fetch the last five rows
x2=df.tail()
print(x2)

x3=df.tail(2)
print(x3)

#fetch the middle data
n=df[2:8]
print(n)

# fetch the specific data from a dataframe
n=df.iloc[2:4,1:3]
print(n)

# add extra colums in a existing dataframe
roll_no=np.arange(1,11)
df["rollno"]=roll_no
print(df)
df.to_csv("info.csv",index="False")
print(df)