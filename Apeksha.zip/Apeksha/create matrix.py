import numpy as np

m1=np.matrix('1,2,3;4,5,6')
print(m1)  

m2=np.matrix('7,8,9;10,11,12')
print(m2)

print()

add=m1+m2
print(add)
print()

sub=m1-m2
print(sub)
print()

div=m1/m2 
print(div)
print()

m2=m2.T 
print(m2)
print()

mul=m1*m2
print(mul)
