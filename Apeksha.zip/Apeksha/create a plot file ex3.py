import pandas as pd
import matplotlib.pyplot as plt
days=["sunday","mon","tue","wed","thu","fri","sat"]
min_temp=[20,21,23,24,25,27,28]
avg=[22,23,25,26,27,28,29]
max_temp=[24,25,26,27,28,29,30]
data=list(zip(days,min_temp,avg,max_temp))
df=pd.DataFrame(data,columns=["days","min_temp","avg","max_temp"])
print(df)
plt.title("temperature data")
plt.xlabel("days")
plt.ylabel("temp")

plt.plot(df["days"].values,df["min_temp"].values,color="blue",marker="o",markersize=10)
plt.plot(df["days"].values,df["avg"].values,color="green",marker="*",markersize=5)
plt.plot(df["days"].values,df["max_temp"].values,color="red",marker="+",markersize=10)
plt.grid()
plt.savefig("line1plot.jpg")
plt.show()