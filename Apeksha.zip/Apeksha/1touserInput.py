n=int(input("Enter a no:"))

if n>1:
    if(n<=50):
        i=1
            while(i<=n):
            i+=1
            print(i)
    else:
        print("out of range")
else:
    print("no is negative or invalid")

if n<0:
    i=0
    if(n>=-50):
        while(i>=n):
            i-=1
            print(i)
    else:
        print("out of range")
else:
    print("no is negative or invalid")



    
    

    
