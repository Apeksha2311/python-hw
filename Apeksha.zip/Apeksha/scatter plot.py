from cProfile import label
import random as r
import matplotlib.pyplot as plt

x=[r.randint(1,99) for i in range(10)]
y=[r.randint(1,99) for i in range(10)]

#plot graph

plt.title("Scatter plot")
plt.xlabel("x-axis")
plt.ylabel("y-axis")

plt.scatter(x,y,color='red',marker="*",label='data')
plt.legend()
plt.grid()
plt.show()