import random as r
import matplotlib.pyplot as plt

x=[r.randint(10,50) for i in range(100)]

plt.title("Hotel customer")
plt.xlabel("Age")
plt.ylabel("No of people")
plt.hist(x,rwidth=0.8,bins=7)
plt.show()