import pandas as pd
name=["nakshatra","shubham","shital","sayali","sai","pooja","apeksha","yogesh","vivek","vaibhav"]
age=[20,21,21,22,19,20,22,24,21,23]
loc=["bhandup","bhandup","thane","vikhroli","kudal","mulund","nahur","dombivli","kanjurmarg","ghatkopar"]
course=["python","java","sql","analyst",".net","analyzer","sql","tester","mathematics","cloud_computing"]
# print(name)
# print(age)
# print(loc)
# print(loc)

data=list(zip(name,age,loc,course))
# print(data)
df=pd.DataFrame(data,columns=["name","age","loc","course"])
print(df)
print(type(df))
df.to_csv("info.csv",index=False)