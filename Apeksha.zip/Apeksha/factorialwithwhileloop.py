n=int(input("enter a value:"))
f=1
while(n>0):
    f=f*n
    n-=1
print(f)
