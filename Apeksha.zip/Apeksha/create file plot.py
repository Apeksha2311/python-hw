import matplotlib.pyplot as plt
#example1:
# x=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"]
# y=[26,22,24,25,29,30,28]
# plt.plot(x,y)
# plt.show()

#example 2:
# x=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"]
# y=[26,22,24,25,29,30,28]
# plt.title("weather")
# plt.xlabel("days")
# plt.ylabel("temperature")
# plt.plot(x,y,marker="o",color="red",linestyle="dotted",markersize=10,markerfacecolor="blue")
# plt.grid()
# plt.savefig("lineplot.jpg")
# plt.show()