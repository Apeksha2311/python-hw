# #1- zeros
import numpy as np


# z=np.zeros((8,))
# print(z)

# z1=np.zeros((3,4))
# print(z1)

# print(z1.ndim)
# print(z1.dtype)

# z2=np.zeros((4,3),dtype = np.int64)
# print(z2)
# print(z2.dtype)

# #2-ones
# x=np.ones((7,))
# print(x)

# x1=np.ones((5,6))
# print(x1)

# print(x1.ndim)
# print(x1.dtype)

# x2=np.ones((3,4),dtype=np.int64)
# print(x2)
# print(x2.dtype)

# #3-arange-it is used to generate the sequence of array and its generate 1'd Array only

# a=np.arange(1,11)
# print(a)

# print(a.dtype)


# print(a.itemsize)
# print(a.size)

#reshape -there are 2 type of reshape
#1-reshape
#2-flatten

#1-reshape
# arr=np.arange(1,9)
# print(arr)
# print(type(arr))
# print(arr.shape)
# print(arr.ndim)

# #(2,4)
# arr2=arr.reshape(2,4)
# print(arr2)
# print(arr2.shape)
# print(arr2.ndim)


# arr3=arr2.reshape(4,2)
# print(arr3)
# print(arr3.shape)
# print(arr3.ndim)

# #for (8,1)
# arr4=arr3.reshape(-1,1)
# print(arr4)
# print(arr4.shape)
# print(arr4.ndim)

# #for (1,8)
# arr5=arr4.reshape(1,-1)
# print(arr5)
# print(arr5.shape)
# print(arr5.ndim)

# arr6=arr5.flatten()
# print(arr6)
# print(arr6.ndim) 





















