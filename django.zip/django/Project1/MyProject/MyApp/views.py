from django.shortcuts import render,HttpResponse

# Create your views here.
def home_view(request):
    # return HttpResponse("<h1>Hello Home Page</h1>")
    return render(request , 'MyApp/home.html')


def about_view(request):
    return HttpResponse("<h1>Hello About Page</h1>")


def contact_view(request):
    return HttpResponse("<h1>Hello Contact Page</h1>")