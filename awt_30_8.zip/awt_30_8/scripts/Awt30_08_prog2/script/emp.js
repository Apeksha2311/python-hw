var myApp=angular.module("myModule",[]);

myApp.controller("myctrl",function($scope)
{var employees=[
    {
        name:'raju',gender:'m'
    },
    {
        name:'appu',gender:'f'
    }

];
$scope.employees=employees



}





);