var myApp = angular.module("md",[]);

myApp.controller("ctrl",function($scope)
{
    var countries=[
    {
        name:"India",
        cities:["mumbai","Sion"]
    },

    {
        name:"USA",
        cities:["Chicago","los"]
    }
];
$scope.countries=countries;


}

);